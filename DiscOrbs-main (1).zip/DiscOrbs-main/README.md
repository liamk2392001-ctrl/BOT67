<h1 align="center">Discorbs - Free Discord Orbs</h1>

###

<div align="center">
  <img height="400" src="https://i.imgur.com/iRh6kW0.png"  />
</div>

###

<h2 align="left">Orbs Price</h2>

###

<p align="left">- <b>2 Week Nitro Boost:</b> 7000 Orbs<br>- <b>1 month Nitro Boost:</b> 14 000 Orbs<br>- <b>1 years Nitro Boost:</b> 168 000 Orbs <br><br>- 4.99$ = 4100 Orbs<br>- 8.99$ = 7600 Orbs<br>- 12.99$ = 11 000 Orbs</p>

###

<h2 align="left">How use script</h2>

###

<p align="left">- Go to <b>https://discord.com/quest-home OR go to Quest tabs</b><br>- Accept quest <b>(random quest, video, game even without having the game)</b><br>- Press <b>CTRL + SHIFT + i</b><br>- Write <b>allow pasting</b><br>- Paste the code</p>

###

<h4 align="left">!! INJECT THE SCRIPT FOR EACH QUEST !!</h4>
